<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>DATA-TOEVOEGEN</title>
</head>

<body>
<?php include "menu.php"; ?>

    <?php

    // importeer
    include 'Database.php';

    if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "INSERT INTO artikel VALUES (:code, :artikel, :prijs)";

        //associative array
        $placeholders = [
            'code' => NULL,
            'artikel' => $_POST['artikel'],
            'prijs' => $_POST['prijs']
        ];

        $db = new database();
        $db->insert($sql, $placeholders, 'Overzicht_artikelen.php');
    }
    ?>

    <form action="nieuw_artikel.php" method="post">
        <input type="text" name="artikel" placeholder="artikel">
        <input type="text" name="prijs" placeholder="prijs">
        <input type="submit" name="submit" value="Artikel Toevoegen">
    </form>

</body>

</html>