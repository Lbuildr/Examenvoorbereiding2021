<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit-artikel</title>
</head>

<body>

<?php

// importeer
include 'Database.php';

// maak een db instance
$db =  new database();

$sql = "SELECT * FROM artikel WHERE artikelcode=:code";
$result = $db->select($sql, ['code'=>$_GET['artikel_id']]);
print_r($result);
if(count($result)>0){
    $artikel = $result[0]['artikel'];
    $prijs = $result[0]['prijs'];
}



if(isset($_POST['submit'])){ 

    $sql = "UPDATE artikel SET artikel=:artikel, prijs=:prijs WHERE artikelcode = :code;";
    
    //associative array 
    $placeholders = [
        'code'=>$_POST['artikelcode'],
        'artikel'=>$_POST['artikel'],
        'prijs'=>$_POST['prijs']        
    ];

    print_r($_POST);

    // roep functie aan uit je database class
    // $db->update($sql, $placeholders);
}
?>
  



<form action="edit_artikel.php" method="post">
    <input type="hidden" name="artikelcode" value="<?php echo isset($_GET['artikel_id']) ? $_GET['artikel_id'] : '';?>">
    <input type="text" name="artikel" placeholder="<?php echo isset($artikel) ? $artikel : 'artikel'?>">
    <input type="text" name="prijs" placeholder="<?php echo isset($prijs) ? $prijs : 'prijs'?>">
    <input type="submit" name="submit" value="Wijzig" >
</form>
    
</body>
</html>