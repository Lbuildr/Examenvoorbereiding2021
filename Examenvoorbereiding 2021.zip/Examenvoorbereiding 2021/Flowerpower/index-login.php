<!DOCTYPE html>
<html lang="NL">

<head>
     <meta http-equiv="content-type" content="text/html; charset=utf-8">
     <title>Flowerpower-Inloggen</title>
</head>

<body>
     <?php include "menu.php"; ?>

     <form action="login.php" method="post">

          <h2>Inloggen</h2>

          <label>Gebruikersnaam</label>
          <input type="text" name="uname" placeholder="Gebruikersnaam/Email">

          <label>Wachtwoord</label>
          <input type="password" name="password" placeholder="Wachtwoord">

          <button type="submit">Bevestigen</button>

          <script>
               <?php if (isset($_GET['error'])) { ?>
                         <p class = "error" > <?php echo $_GET['error']; ?> </p>
               <?php } ?>
          </script>
     </form>
</body>
<style>
     form {
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: white;
          margin-left: 20%;
          margin-right: 20%;
          border: 2px solid green;
          position: block;
     }

     h2 {
          text-align: center;
          margin-bottom: 10px;
          color: green;
     }

     .error {
          background: #F2DEDE;
          color: #A94442;
          padding: 10px;
          width: 95%;
          border-radius: 5px;
          margin: 20px auto;
     }
</style>

</html>