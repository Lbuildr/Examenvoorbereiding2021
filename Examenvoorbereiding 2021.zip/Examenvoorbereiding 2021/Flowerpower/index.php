<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flowerpower</title>
</head>
<body>
<?php include("menu.php") ?>

<img src="../flowerpower/Media/Boeket.jpg" alt="Flowers in Chania">
<img src="../flowerpower/Media/Winkel.jpg" alt="Flowers in Chania">

    <?php
        include 'Database.php';
        $db = new database();
        $winkels = $db->select("SELECT * FROM winkels", []);

        $columns = array_keys($winkels[0]);
        $row_data = array_values($winkels);

    ?>

    <table>
    <tr>
    <?php

            foreach($columns as $column){
                echo "<th><strong> $column </strong></th>";
            }
    ?>
    </tr>
    <?php
            foreach($row_data as $row){ ?>
                <tr>
                <?php
                foreach($row as $data){
                     echo "<td> $data  </td>";
                }
            }
        ?>

    </table>



</body>
</html>