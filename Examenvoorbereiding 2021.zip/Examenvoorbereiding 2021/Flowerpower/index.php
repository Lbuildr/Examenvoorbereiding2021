<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">

    <title>Flowerpower</title>
</head>

<body>
    <?php include "menu.php"; ?>
    <!---------------------------------------Home Pagina Content------------------------------------->
    <div id="Hero">
        <video autoplay muted loop id="Video">
            <source position="cover" src="../flowerpower/media/Flowerpowervid4K.mp4" type="video/mp4">
        </video>
        <?php
        include 'Database.php';
        $db = new database();
        $winkel = $db->select("SELECT * FROM winkel", []);

        $columns = array_keys($winkel[0]);
        $row_data = array_values($winkel);

        ?>

        <table id="Winkels">
            <tr>
                <?php

                foreach ($columns as $column) {
                    echo "<th><strong> $column </strong></th>";
                }
                ?>
            </tr>
            <?php
            foreach ($row_data as $row) { ?>
                <tr>
                <?php
                foreach ($row as $data) {
                    echo "<td> $data  </td>";
                }
            }
                ?>

        </table>

    </div>

    <div class="pictures">
            <img src="../flowerpower/Media/Boeket.jpg" alt="Flowers in Chania">
            <img src="../flowerpower/Media/Winkel.jpg" alt="Flowers in Chania">
        </div>

</body>
</html>