<!DOCTYPE html>
<html lang="en">

<head>
  <script src="https://kit.fontawesome.com/4f8af57439.js" crossorigin="anonymous"></script>
  <link href="https://cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<link rel="stylesheet" href="menu.css">
  <meta charset="UTF-8">
  <title>MENU</title>
</head>

<body>

  <!-- Preloader -->
  <div class="se-pre-con"></div>

  <script>
    // Wait for window load
    $(window).load(function() {
      // Animate loader off screen
      $(".se-pre-con").fadeOut("slow");;
    });
  </script>
  <!-- End Preloader -->

  <nav>
    <div class="header">
      <div class="logo">Flowerpower <img style="height:50px;" src="PeaShooter.png" alt=""></div>
      <div class="header-bellow">
        <a href="index.php">Home</a>
        <a href="Overzicht_artikelen.php">Artikelen</a>
        <a href="Contact.php">Contact</a>
        <a href="Index-login.php">Inloggen</a>
        <a onclick="uitloggen()">Loguit</a>
      </div>

      <script>
        const currentLocation = location.href;
        const menuItem = document.querySelectorAll('a');
        const menuLength = menuItem.length
        for (let i = 0; i < menuLength; i++) {
          if (menuItem[i].href === currentLocation) {
            menuItem[i].className = "active"
          }
        }
        //--------------------UITLOGGEN---------------------------------------------
        function uitloggen() {
          var loguit = confirm('Weet u zeker dat u wilt uitloggen?');
          if (loguit) {
            location.href = 'index.php?page=uitloggen';
          }
        }
        //--------------- NAVIGATION transparent-> white -----------------------------

        window.addEventListener('scroll', function() {
          let header = document.querySelector('header');
          let windowPosition = window.scrollY > 0;
          header.classList.toggle('scrolling-active', windowPosition);
        })

        //======================Page Loader active==================================*/
        $('#preloader').fadeOut();
      </script>
      <nav>
    </div>
</body>

</html>