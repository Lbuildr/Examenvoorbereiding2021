<?php
        include 'Database.php';
        $db = new database();
        $medewerkers = $db->select("SELECT * FROM medewerkers", []);

        $columns = array_keys($medewerkers[0]);
        $row_data = array_values($medewerkers);

    ?>

    <table>
    <tr>
    <?php

            foreach($columns as $column){
                echo "<th><strong> $column </strong></th>";
            }
    ?>
    </tr>
    <?php
            foreach($row_data as $row){ ?>
                <tr>
                <?php
                foreach($row as $data){
                     echo "<td> $data  </td>";
                }
            }
        ?>

    </table>