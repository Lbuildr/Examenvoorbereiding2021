<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>OVERZICHT_ARTIKELEN</title>
  <script src="https://kit.fontawesome.com/03b15537fd.js" crossorigin="anonymous"></script>

</head>

<body>

  <?php include "menu.php"; ?>


  <?php
  include 'Database.php';
  $db = new database();
  $artikel = $db->select("SELECT * FROM artikel", []);

  $columns = array_keys($artikel[0]);
  $row_data = array_values($artikel);

  ?>

  <table style="background: linear-gradient(95deg, #5533ff 40%, #25ddf5 100%);
                    position: absolute; left:0; top: 20%;  
                        color:white; padding:5px; border-radius: 10px;">
    <tr>
      <?php foreach ($columns as $column) { ?>
        <th>
          <strong>
            <?php echo $column; ?>
          </strong>
        </th>

      <?php    }    ?>
      <th colspan="3">actie</th>
    </tr>
    <?php foreach ($row_data as $row) { ?>
      <tr>
        <?php

        $artikel_id = $row['artikelcode'];

        foreach ($row as $data) { ?>
          <td>
            <?php echo $data; ?>
          </td>
        <?php } ?>

        <td>
          <a class="tooltip" href="edit_artikel.php?artikel_id=<?php echo $artikel_id ?>"><i class="fas fa-pencil-alt"></i>
            <p class="tooltiptext">Edit</p>
          </a>

          <a class="tooltip" href="delete_artikel.php?artikel_id=<?php echo $artikel_id ?>"><i class="fas fa-trash-alt"></i>
            <p class="tooltiptext">Delete</p>
          </a>
        </td>
      <?php
    }
      ?>

      </tr>

  </table>
  <form action="nieuw_artikel.php" method="post">
    <input type="submit" value="Voeg artikel toe">
  </form>

</body>

<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  /*----------------TOOLTIP STYLE--------------*/
  a {
    text-decoration: none;
    color: black;
  }

  a:hover {
    color: grey;
    opacity: 10;
  }

  .tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
  }

  .tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    top: 90%;
    left: 50%;
    margin-left: -60px;
  }

  .tooltip .tooltiptext::after {
    content: "";
    position: absolute;
    bottom: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: transparent transparent black transparent;
  }

  .tooltip:hover .tooltiptext {
    visibility: visible;
  }

  /*FORM STYLE  */
  .FORM_GEGEVENS {
    background-color: blue;
    color: white;

  }
</style>
</html>

