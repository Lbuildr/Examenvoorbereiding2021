<!DOCTYPE html>
<html lang="NL">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title>Flowerpower</title>
    <link rel="stylesheet" href="css/Medewerkers-menu.css" />
    <script>
        function uitloggen() {
            var loguit = confirm('Weet u zeker dat u wilt uitloggen?');
            if (loguit) {
                location.href = 'index.php?page=uitloggen';
            }
        }
    </script>
</head>

<body>
    <div class="header">
        <Div class="logo"></Div>
        <div class="nav-Employee">
            <ul>
                <li onclick="location.href='Overzicht_artikelen.php'">Overzicht van Artikelen</li>
                <li onclick="location.href='Overzicht_Medewerkers.php'">Overzicht van Medewerkers</li>
                <li onclick="location.href='Artikelen_Bestellen.php'">Te bestellen producten</li>
                <li onclick="location.href='Overzicht_artikelen.php'">nog niks bekend</li>
                <li onclick="location.href='../menu/InloggenCustomer.php'">nog niks bekend</li>
                <li onclick="uitloggen()">uitloggen</li>
            </ul>
        </div>
    </div>
    </div>
</body>

</html>